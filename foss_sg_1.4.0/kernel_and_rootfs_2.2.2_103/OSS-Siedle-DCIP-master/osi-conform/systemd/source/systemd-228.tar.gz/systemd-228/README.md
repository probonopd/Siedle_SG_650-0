# systemd - System and Service Manager

[![Build Status](https://semaphoreci.com/api/v1/projects/28a5a3ca-3c56-4078-8b5e-7ed6ef912e14/443470/shields_badge.svg)](https://semaphoreci.com/systemd/systemd)<br/>
[![Coverity Scan Status](https://scan.coverity.com/projects/350/badge.svg)](https://scan.coverity.com/projects/350)

## Details

 * General information about systemd can be found in the [systemd Wiki](http://www.freedesktop.org/wiki/Software/systemd)
 * Information about build requirements are provided in the [README file](../master/README)
