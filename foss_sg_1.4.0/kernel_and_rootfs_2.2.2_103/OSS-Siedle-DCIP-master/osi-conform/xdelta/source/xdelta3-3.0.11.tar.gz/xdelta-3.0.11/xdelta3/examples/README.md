Files in this directory demonstrate how to use the Xdelta3 API.  Copyrights
are held by the respective authors and these files are not covered by the GPL.

small_page_test.c -- how to use xdelta3 in an environment such as the kernel
for small pages with little memory

encode_decode_test.c -- how to use xdelta3 to process (encode/decode) data in
multiple windows with the non-blocking API
