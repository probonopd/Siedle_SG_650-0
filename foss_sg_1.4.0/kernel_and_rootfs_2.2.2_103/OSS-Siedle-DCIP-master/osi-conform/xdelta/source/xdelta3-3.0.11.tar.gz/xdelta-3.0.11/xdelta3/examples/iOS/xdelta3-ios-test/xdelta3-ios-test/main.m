//
//  main.m
//  xdelta3-ios-test
//
//  Created by Joshua MacDonald on 6/16/12.
//  Copyright (c) 2011, 2012 Joshua MacDonald. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Xd3iOSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Xd3iOSAppDelegate class]));
    }
}
