#include <mysql.h>
#include <stdio.h>

int main() {
	printf("%s", MYSQL_SERVER_VERSION);
}
