cat > /tmp/ser_fifo << EOF
:get_domaincode:response_fifo
iptel.org
1

EOF
