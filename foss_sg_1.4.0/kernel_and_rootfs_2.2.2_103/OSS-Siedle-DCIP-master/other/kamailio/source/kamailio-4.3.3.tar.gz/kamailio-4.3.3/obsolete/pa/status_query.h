#ifndef __STATUS_QUERY_H
#define __STATUS_QUERY_H

int target_online(struct sip_msg* _m, char* _domain, char* _s2);
/* add other query functions: get_online_contact, ... */

#endif
