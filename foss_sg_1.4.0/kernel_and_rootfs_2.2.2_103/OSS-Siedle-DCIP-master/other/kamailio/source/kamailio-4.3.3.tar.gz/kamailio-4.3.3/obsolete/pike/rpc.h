#ifndef __PIKE_RPC_H
#define __PIKE_RPC_H

#include "../../rpc.h"

extern rpc_export_t pike_rpc_methods[];


#endif
