cat /tmp/ser_reply &
cat > /tmp/ser_fifo << EOF
:pdt_add:ser_reply
55
123.com

EOF
