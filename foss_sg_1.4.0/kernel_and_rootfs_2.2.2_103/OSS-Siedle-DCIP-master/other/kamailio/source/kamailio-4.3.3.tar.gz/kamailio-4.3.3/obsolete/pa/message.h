#ifndef __MESSAGE_H
#define __MESSAGE_H

/* message processing */

int authorize_message(struct sip_msg* _m, char* _filename, char*);

#endif
