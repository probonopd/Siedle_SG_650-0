#ifndef __RLS_RPC_H
#define __RLS_RPC_H

#include "../../rpc.h"

extern rpc_export_t rls_rpc_methods[];

#endif
